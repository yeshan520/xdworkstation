#!/usr/bin/env python3
# encoding: utf-8

"""Entry point for all things UltiSnips."""

from UltiSnips.snippet_manager import UltiSnips_Manager
